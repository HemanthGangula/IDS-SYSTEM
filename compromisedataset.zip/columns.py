df_columns = ["DestMac", "SrcMac", "EthProtocol", "Version", "TTL", "Proto",
                  "SrcIP", "DestIP", "ICMPType", "ICMPCode", "TCPSourcePort", "TCPDestPort", "TCPSequence",
                  "TCPAcknowledgement", "FlagURG", "FlagACK", "FlagPSH", "FlagRST", "FlagSYN", "FlagFIN",
                  "UDPSrcPort", "UDPDestPort", "UDPLength", "Duration",
                  "ARP_HW_Type", "ARP_Proto_Type", "ARP_Opcode",
                  "ARP_Sender_MAC", "ARP_Sender_IP", "ARP_Target_MAC", "ARP_Target_IP"]
